#include "closure.h"
#include "environment.h"

using namespace std;

Closure::Closure()
{	
	this->init();
	formalparameters = NULL;
	body = NULL;
	storedenv = NULL;
}

Closure::Closure(Managed p, Managed b, ManagedEnv env)
{
	this->init();
	formalparameters = p;
	body = b;
	storedenv = env;
}

Closure::~Closure()
{
	formalparameters = NULL;
	body = NULL;
	storedenv = NULL;
}	
	
Managed Closure::apply(Managed actualparameters)
{
	ManagedEnv instance = new Environment(storedenv);
	instance->extend(formalparameters, actualparameters);
	return body->eval_block(instance);
}

void Closure::print(ostream& out)
{
	cout << "closure : ";
	
	if (formalparameters == NULL)
		out << "()";
	else
		formalparameters->print(out);
	
	cout << " ";
	body->print(out);
}
