#include "managed.h"
#include "sexpr.h"


Managed::Managed()
{
	sp = NULL;
}

Managed::Managed(Sexpr* newsp)
{
	sp = NULL;
	this->assign(newsp);
}

Managed::Managed(const Managed& M)
{
	sp = NULL;
	this->assign(M.sp);
}

Managed::~Managed()
{
	this->assign(NULL);
}

Managed& Managed::operator=(Sexpr* rhs)
{
	this->assign(rhs);
	return *this;
}

Managed& Managed::operator=(const Managed& rhs)
{
	this->assign(rhs.sp);
	return *this;
}

bool Managed::operator==(const Managed& rhs)
{
	if (sp == rhs.sp)
		return true;
	else
		return false;
}

bool Managed::operator!=(const Managed& rhs)
{
	if (sp != rhs.sp)
		return true;
	else
		return false;
}

Sexpr* Managed::operator->()
{
	return sp;
}

void Managed::assign(Sexpr* newsp)
{
	if (newsp != sp)
	{	
		if (sp != NULL)
			sp->dec();

		if (newsp != NULL)
			newsp->inc();

		sp = newsp;
	}
}
