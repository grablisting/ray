#include "environment.h"
#include <iostream>
#include "sexpr.h"
#include "managed.h"

using namespace std;

Environment::Environment()
{
	refcount = 0;
	next = NULL;
}

Environment::Environment(ManagedEnv lastenv)
{
	refcount = 0;
	next = lastenv;
}

Environment::~Environment()
{	
	env.clear();
	next = NULL;
}

void Environment::print(ostream& out)
{	
	if (!env.empty())
	{
		map<string, Managed>::iterator p;
		for(p = env.begin(); p != env.end(); p++)
		{
			out << "   " << p->first << " : ";
			
			if (p->second == NULL)
				out << "()";
			else
				p->second->print(out);
			
			out << endl;
		}
		if (next != NULL)
		{
			if (!next->env.empty())
			{
				cout << "Next environment:" << endl;
				next->print(out);
			}
		}
	}
	else
	{
		out << "*environment is empty*";
	}
}

void Environment::insert(Managed key, Managed value)
{	
	env[key->get_string()] = value;
}

void Environment::extend(Managed keys, Managed vals)
{
	if (keys != NULL)
	{
		this->insert(keys->get_first(), vals->get_first());
	
		if (keys->get_rest() != NULL)
			this->extend(keys->get_rest(), vals->get_rest());
	}
}

void Environment::set(Managed key, Managed value)
{
	map<string, Managed>::iterator p;
	p = env.find(key->get_string());
	
	if (p == env.end())
	{
		if (next != NULL)
		{
			next->set(key, value);
		}
	}
	env[key->get_string()] = value;
}

Managed Environment::lookup(Managed key)
{
	map<string, Managed>::iterator p;
	p = env.find(key->get_string());
	
	if (p != env.end())
		return env.find(key->get_string())->second;
	else if (p == env.end() && next != NULL)
		return next->lookup(key);
	else
		return NULL;
}

void Environment::inc()
{
	refcount += 1;
}

void Environment::dec()
{
	if (refcount > 0)
	{
		refcount -= 1;

		if (refcount == 0)
			delete this;
	}
}
